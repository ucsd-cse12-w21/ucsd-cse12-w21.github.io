package src.ucsdcse12pa5student;

public interface Partitioner{
	int partition(String[] nums, int low, int high);
}
