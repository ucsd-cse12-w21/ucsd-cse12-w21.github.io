package student;

public interface Student{
	public String getName();
	public Course[] getCourses();
	public void addCourse(Course course); //what we want to test
}
