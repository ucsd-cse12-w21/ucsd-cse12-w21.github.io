package student;

//A reference implementation of a couple example JUnit tests for testing addCourse
import java.util.Collection;
import java.util.Arrays;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class StudentTest{
	public static Collection<Object[]> STUDENTNUMS =
			Arrays.asList(new Object[][] { {'A'}, {'B'}, {'C'} });
	private int studentType;

	public StudentTest(char studentType) {
		super();
		this.studentType = studentType;
	}
	
	//Helper method to check whether two course lists have same course names
	public static boolean correctCourseList(Course[] expected, Course[] returned){
		if(expected.length != returned.length){
			return false;
		}
		
		for(int i = 0; i < expected.length; i++){
			int count = 0;
			for(int j = 0; j < returned.length; j++){
				if(expected[i].isEqualTo(returned[j])){
					count++;
				}
			}
			if(count != 1){
				return false;
			}
		}
		return true;
	}

	@Parameterized.Parameters(name = "Student{0}")
	public static Collection<Object[]> students() {
		return STUDENTNUMS;
	}
		
	private Student makeStudent(String name, Course[] courses) {
		switch(this.studentType) {
			case 'A': return new StudentA(name, courses);
			case 'B': return new StudentB(name, courses);
			case 'C': return new StudentC(name, courses);
		}
		return null;
	}

	//Some possible JUnit tests below	
	
	// this test checks if the course list size increments by 1
	@Test
	public void addedHasCount1() {
		String n = "Rick Smith";
		Course[] courses = {};
		Student student = makeStudent(n, courses);
		
		student.addCourse(new Course("CSE12"));
		assertEquals(1 , student.getCourses().length);
		
	}
	
	
	@Test
	public void cantAddDuplicate() {
		String n = "Rick Smith";
		Course[] courses = {new Course("CSE12"), new Course("CSE50")};
		Student student = makeStudent(n, courses);
		
		Course test = new Course("CSE12");
		student.addCourse(test);
		
		//Which test is more robust?
		
		//assertEquals(2, student.getCourses().length);
		
		assertEquals(true, correctCourseList(courses, student.getCourses()));
	}
	
	@Test
	public void addReturnsCorrectCourselist() {
		String n = "Rick Smith";
		Course[] courses = {new Course("CSE12"), new Course("CSE50")};
		Student student = makeStudent(n, courses);
		
		Course test = new Course("CSE60");
		student.addCourse(test);
		
		Course[] updated = {courses[0], courses[1], test};
		assertEquals(true, correctCourseList(updated, student.getCourses()));
	}
	
}




