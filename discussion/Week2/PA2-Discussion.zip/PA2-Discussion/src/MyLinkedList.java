
class Node<E> {
	  E value;
	  Node<E> next;
	  public Node(E value, Node<E> next) {
	    this.value = value;
	    this.next = next;
	  }
	}

	public class MyLinkedList<E> implements GList<E> {

	  Node<E> front;
	  int size;

	  public MyLinkedList() {
	    this.front = new Node<E>(null, null);
	  }

	  public void prepend(E e) {
	    Node<E> newFront = new Node<E>(e, this.front.next);
	    this.front.next = newFront;
	    this.size += 1;
	  }

	  public E get(int index) {
	    Node<E> current = this.front.next;
	    for(int i = 0; i < index; i += 1) {
	      current = current.next;
	    }
	    return current.value;
	  }

	  public void add(E e) {
	    // NOTE: we start at this.front, because what we need
	    // for add() is a reference to a node to add to, which may
	    // be front itself if the list is empty.

	    // If we didn't have the dummy/sentinel node at the
	    // beginning, we would need to check if front was null,
	    // special case that behavior, and then have the loop
	    // below.
	    Node<E> current = this.front;
	    while(current.next != null) {
	      current = current.next;
	    }
	    current.next = new Node<E>(e, null);
	    this.size += 1;
	  }

	  public int size() {
	    return this.size;
	  }
	  
	  public void remove(int index){  
		// Check if valid index  
		if (index < 0 || index >= size) {
			return;
		}  
		  
	    Node<E> current = this.front;

	    for(int i = 0; i < index; i += 1) {
	      current = current.next;
	    }

	    current.next = current.next.next;  
	    this.size -= 1;
	  
	    return;
	  }
	  

	  public void insert(int index, E e){
		// Check if valid index  
		if (index < 0 || index > size) {
			return;
		}   
		
	    Node<E> current = this.front;

	    for(int i = 0; i < index; i += 1) {
	      current = current.next;
	    }

	    current.next = new Node<E>(e, current.next);
	    this.size += 1;
		  
	    return;
	  }

	}