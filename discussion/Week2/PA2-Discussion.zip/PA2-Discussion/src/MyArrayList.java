
public class MyArrayList<E> implements GList<E> {

	  E[] elements;
	  int size;

	  public MyArrayList() {
	    this.elements = (E[]) new Object[2]; // TODO
	    this.size = 0;
	  }

	  public void add(E e) {
	    expandCapacity();
	    this.elements[this.size] = e;
	    this.size += 1;
	  }

	  public E get(int index) {
	    // TODO: Check for out-of-bounds
	    // throw IndexOutOfBoundsException
	    return this.elements[index];
	  }

	  public int size() {
	    return this.size;
	  }

	  private void expandCapacity() {
	    int currentCapacity = this.elements.length;
	    if(this.size < currentCapacity) { return; }

	    E[] expanded = (E[]) new Object[currentCapacity * 2];

	    for(int i = 0; i < this.size; i += 1) {
	      expanded[i] = this.elements[i];
	    }
	    this.elements = expanded;
	  }


	  public void remove(int index){
		if (index < 0 || index >= size) {
			return;
		}
		
	    for(int i = index; i < this.size; i++){
	      this.elements[i] = this.elements[i + 1];
	    }
		
	    this.elements[size] = null;
	    this.size -= 1;
		  
	    return;
	  }
	  
	  //Assumes a valid index is given
	  public void insert(int index, E e){
	    expandCapacity();
		if (index < 0 || index > size) {
			return;
		}
	    for(int i = this.size; i > index; i--){
	      this.elements[i] = this.elements[i - 1];
	    }
	    
	    this.elements[index] = e;
	    this.size += 1;
		  
	  }
	  
	  //Just call insert at index 0!
	  public void prepend(E e){
		  this.insert(0, e);
		  return;
	  }
	}